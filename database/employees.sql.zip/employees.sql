-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 19, 2016 at 11:28 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my_php`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `U_name` varchar(15) DEFAULT NULL,
  `Password` varchar(15) NOT NULL,
  `pic` varchar(20) NOT NULL,
  `Full_name` varchar(25) DEFAULT NULL,
  `Maile` varchar(20) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Pos` varchar(20) NOT NULL,
  `Emp_id` int(99) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`U_name`, `Password`, `pic`, `Full_name`, `Maile`, `Phone`, `Pos`, `Emp_id`) VALUES
('9', '99', 'prods/', '', '', '', '', 18);
