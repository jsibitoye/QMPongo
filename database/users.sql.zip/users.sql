-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 19, 2016 at 11:28 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my_php`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `U_name` varchar(15) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `pic` varchar(20) NOT NULL,
  `Full_name` varchar(25) NOT NULL,
  `Maile` varchar(20) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Occupation` varchar(15) NOT NULL,
  `U_id` int(99) NOT NULL AUTO_INCREMENT,
  `Reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`U_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`U_name`, `Password`, `pic`, `Full_name`, `Maile`, `Phone`, `Occupation`, `U_id`, `Reg_date`) VALUES
('j', 'j', 'prods/', 'Ibitoye joshua', 'ljlk', '4885893', 'ceo', 5, '2016-03-19 06:38:01');
